function download_txt() {
  var textToSave = document.getElementById('jsondata').innerHTML;
  var hiddenElement = document.createElement('a');

  hiddenElement.href = 'data:attachment/text,' + encodeURI(textToSave);
  hiddenElement.target = '_blank';
  hiddenElement.download = 'patients.json';
  hiddenElement.click();
}

document.getElementById('test').addEventListener('click', download_txt);